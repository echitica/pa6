Color complementColor(Color c) {
  return new Color(c.getRed(), c.getBlue(), c.getGreen());
}
Color first = new Color(200, 100, 150);
Color complementColorExample1 = complementColor(first);
Color complementColorExample1Ex = new Color(200, 150, 100);
Color purple = new Color(255, 0, 255);
Color complementColorExample2 = complementColor(purple);
Color complementColorExample2Ex = new Color(255, 255, 0);

Color[] complementPixels(Color [] originalPixels) {
  int size = originalPixels.length;
  Color[] newArray = new Color[size];
  for(int i = 0; i < size; i += 1) {
    newArray[i] = complementColor(originalPixels[i]);
  }
  return newArray;
}
Color[] colorArray1 = {purple, purple, first};
Color[] complementPixelsExample1 = complementPixels(colorArray1);
Color[] complementPixelsExample1Ex = {new Color(255, 255, 0), new Color(255, 255, 0), new Color(200, 150, 100)};
Color[] colorArray2 = {new Color(100, 250, 100), new Color(250, 100, 100), new Color(100, 100, 250)};
Color[] complementPixelsExample2 = complementPixels(colorArray2);
Color[] complementPixelsExample2Ex = {new Color(100, 100, 250), new Color(250, 100, 100), new Color(100, 250, 100)};

Image complement(Image original) {
  int width = original.getWidth();
  int height = original.getHeight();
  Color[] pixels = complementPixels(original.getPixels());
  return new Image(width, height, pixels);
}
Image purp = readImage("image-files/Purple.jpg");
Image camp = readImage("image-files/Campfire.jpg");
Image meme = readImage("image-files/cute_cat_and_dog_3.jpg");
Image crane = readImage("image-files/crane.jpg");
Image check = readImage("image-files/checker5.bmp");
Image greenCheck = readImage("image-files/checker5green.bmp");
Image complementExample1 = complement(purp);
Image complementExample2 = complement(crane);
Image complementExample3 = complement(greenCheck);





Color chromascaleColor(Color c, Color target) {
  int avg = (c.getRed() + c.getGreen() + c.getBlue())/3;
  double ratio = avg/255.00;
  return new Color(doubleToInt(target.getRed()*ratio), doubleToInt(target.getGreen()*ratio), doubleToInt(target.getBlue()*ratio));
}
Color chroma = new Color(200, 180, 135);
Color scale = new Color (60, 195, 210);
Color chromascaleColorExample1 = chromascaleColor(chroma, purple);
Color chromascaleColorExampleEx1 = new Color(171, 0, 171);
Color chromascaleColorExample2 = chromascaleColor(purple, chroma);
Color chromascaleColorExampleEx2 = new Color(133, 120, 90);
Color chromascaleColorExample3 = chromascaleColor(chroma, scale);
Color chromascaleColorExampleEx3 = new Color(40, 130, 140);

Color[] chromascalePixels(Color[] originalPixels, Color target) {
  int size = originalPixels.length;
  Color[] newArray = new Color[size];
  for(int i = 0; i < size; i += 1) {
    newArray[i] = chromascaleColor(originalPixels[i], target);
  }
  return newArray;
}
Color[] colorArray3 = {chroma, first, scale};
Color[] chromascalePixelsExample1 = chromascalePixels(colorArray3, purple);
Color[] chromascalePixelsExample1Ex = {new Color(171, 0, 171), new Color(150, 0, 150), new Color(155, 0, 155)};
Color[] test = {scale, purple};
Color[] chromascalePixelsExample2 = chromascalePixels(test, scale);
Color[] chromascalePixelsExample2Ex = {new Color(36, 118, 127), new Color(40, 130, 140)};

Image chromascale(Image original, Color target) {
  int width = original.getWidth();
  int height = original.getHeight();
  Color[] pixels = chromascalePixels(original.getPixels(), target);
  return new Image(width, height, pixels);
}
Image chromascaleExample1 = chromascale(camp, scale);
Image chromascaleExample2 = chromascale(purp, chroma);
Image chromascaleExample3 = chromascale(meme, first);





Color gradientColor(Color color1, Color color2, double weightFor1){
  return new Color();
}

Color[] gradientPixels(int numPixels, Color color1, Color color2){

}

Image gradient(int imageWidth, int imageHeight, Color color1, Color color2){

}

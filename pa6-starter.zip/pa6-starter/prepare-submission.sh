zip pa6.zip PA6.java Analysis.txt image-files/* -x image-files/cute_cat_and_dog_3.jpg -x image-files/crane.jpg -x image-files/checker5.bmp -x image-files/checker5green.bmp
